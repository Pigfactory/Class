/*:
 # Access Control
 
 1. **Access Control**
 2. **Getters and Setters**
 3. **Types**
 
 by Giftbot
*/
//: [Next](@next)
