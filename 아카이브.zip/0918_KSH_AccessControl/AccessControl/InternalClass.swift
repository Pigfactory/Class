//
//  InternalClass.swift
//  AccessControl
//
//  Created by giftbot on 17/09/2018.
//  Copyright © 2018 giftbot. All rights reserved.
//

import Foundation

class InternalClass {
  var someProperty = 30
}
