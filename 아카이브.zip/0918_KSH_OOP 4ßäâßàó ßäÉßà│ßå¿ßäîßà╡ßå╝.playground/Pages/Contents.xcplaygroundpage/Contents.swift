/*:
 # OOP : Object-Oriented Programming
 
 1. **Abstraction**
 2. **Encapsulation**
 3. **Inheritance**
 4. **Polymorphism**
 
 by Giftbot
*/
//: [Next](@next)
